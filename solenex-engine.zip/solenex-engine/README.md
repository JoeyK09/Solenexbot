# Solenex Bot Engine (Phase 1 core)

Multi-tenant Telegram bot engine + auth shell, backed by Postgres. One
server process runs every client's bot -- each bot is a row in the
database, not a separate deployment.

## Deploying on Render (recommended path)

1. **Push this folder to a GitHub repo.**
2. **Create a Postgres instance on Render** (Render dashboard -> New ->
   Postgres, free tier is fine to start). Copy its **Internal Database URL**.
3. **Create a Web Service on Render**, connect it to your repo:
   - Build command: `npm install`
   - Start command: `npm start`
4. **Set environment variables** in the Render dashboard (Environment tab):
   - `JWT_SECRET` -- any long random string
   - `BASE_URL` -- your Render service URL, e.g. `https://solenex-engine.onrender.com`
   - `DATABASE_URL` -- the Internal Database URL from step 2
   - `PGSSL` -- leave as `true` (Render Postgres requires SSL)
5. Deploy. On boot, the server automatically creates all tables if they
   don't exist yet (see `src/db/index.js` -> `init()`), so there's no
   separate migration step to run.

Your server must be reachable over **public HTTPS** for Telegram to
deliver webhooks -- Render gives you this automatically, no ngrok needed
once deployed.

## Local development

```bash
npm install
cp .env.example .env
# edit .env: JWT_SECRET, BASE_URL (use ngrok for a public HTTPS tunnel), DATABASE_URL
npm start
```

For `DATABASE_URL` locally, either point at a local Postgres instance or
just use your Render Postgres's **External Database URL** for quick testing.

## How the multi-tenancy works

- `POST /webhook/:botId` is the **only** Telegram-facing route, shared by
  every bot on the platform.
- Each bot's config (token, template type, settings) lives in the `bots`
  table in Postgres, `config_json` as a `jsonb` column.
- When Telegram calls the webhook, `botManager.handleUpdate` looks up the
  bot by `:botId`, checks the `X-Telegram-Bot-Api-Secret-Token` header
  against the stored `webhook_secret`, then hands the update to the right
  template handler (`faq`, `subscription`, etc).
- Adding a new bot = one DB insert + one `setWebhook` call. No new server
  process, no redeploy.

## API quick reference

```
POST /api/auth/register        { email, password }
POST /api/auth/login           { email, password } -> { token, user }

# All /api/bots routes require: Authorization: Bearer <token>
GET    /api/bots                     list your bots
POST   /api/bots                     { name, telegramToken, templateType, config }
DELETE /api/bots/:id
```

### Creating a FAQ bot

```json
POST /api/bots
{
  "name": "Shop Helper",
  "telegramToken": "123456:ABC-from-BotFather",
  "templateType": "faq",
  "config": {
    "welcomeMessage": "Hi! Ask me about our shop.",
    "faqs": [
      { "keywords": ["hours", "open"], "answer": "We're open 8am-6pm daily." },
      { "keywords": ["location", "where"], "answer": "We're at Westlands, Nairobi." }
    ],
    "fallback": "Not sure -- a human will follow up shortly."
  }
}
```

### Creating a subscription bot (Telegram Stars)

```json
POST /api/bots
{
  "name": "Signals Bot",
  "telegramToken": "987654:XYZ-from-BotFather",
  "templateType": "subscription",
  "config": {
    "welcomeMessage": "Get premium trading signals. Send /subscribe.",
    "productTitle": "Monthly Signal Access",
    "productDescription": "30 days of premium signals.",
    "priceStars": 50,
    "privateChannelId": -1001234567890,
    "durationDays": 30
  }
}
```

To use `privateChannelId`, add your bot as an **admin** of that private
channel first (with "invite users" permission) -- grab the channel ID by
forwarding a message from it to `@userinfobot` or via `getUpdates`.

## What's stubbed vs production-ready

- **Token storage**: `telegram_token` is stored in plaintext in this MVP.
  Before real users onboard, encrypt it at rest (e.g. `libsodium` or a KMS).
- **Expiry sweep**: `subscriptionBot.expireOverdueSubscribers(bot, {...})`
  exists but isn't scheduled yet -- wire it to a daily cron per active
  subscription bot (Render has a "Cron Job" service type for this).
- **M-Pesa/crypto**: not in this MVP; Stars was the fastest path to a
  working payment loop. Plug M-Pesa in as a second "payment provider"
  alongside Stars when you're ready -- the `subscriptionBot` template is
  the place to extend.
- **Connection pooling**: uses `pg`'s default `Pool` settings, fine for
  low-to-moderate traffic. Revisit pool size once you have real load.

## Dashboard

A static, no-build-step dashboard lives in `public/` and is served
automatically by the same Express server — visit your `BASE_URL` in a
browser and you'll see it, no separate deployment needed.

- Sign up / sign in (JWT stored in the browser's localStorage)
- See all your bots with a live/paused status dot
- Connect a new bot (FAQ or Subscription) with a form
- Disconnect a bot

It's plain HTML/CSS/JS (`public/index.html`, `styles.css`, `app.js`) —
no npm packages, no build tool, so there's nothing extra to install for it
to work once the server is deployed.
